#1
def number_of_food_groups():
    return 5
print(number_of_food_groups())
# output 5

#2
def number_of_military_branches():
    return 5
print(number_of_days_in_a_week_silicon_or_triangle_sides() + number_of_military_branches())
#output error, not defined

#3
def number_of_books_on_hold():
    return 5
    return 10
print(number_of_books_on_hold())